%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Includes %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:-  use_module(library(random)),
    consult(utilities),
    consult(board),
    consult(symple),
    consult(ai),
    play.